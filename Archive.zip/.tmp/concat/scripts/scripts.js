'use strict';

/**
 * @ngdoc overview
 * @name bulbasaurApp
 * @description
 * # bulbasaurApp
 *
 * Main module of the application.
 */
angular
  .module('bulbasaurApp', [
    'ngAnimate',
    'ngMessages',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(["$routeProvider", function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl',
        controllerAs: 'about'
      })
      .otherwise({
        redirectTo: '/'
      });
  }]);

'use strict';

/**
 * @ngdoc function
 * @name bulbasaurApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the bulbasaurApp
 */
angular.module('bulbasaurApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });

'use strict';

/**
 * @ngdoc function
 * @name bulbasaurApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the bulbasaurApp
 */
angular.module('bulbasaurApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
