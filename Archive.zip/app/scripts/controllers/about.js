'use strict';

/**
 * @ngdoc function
 * @name bulbasaurApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the bulbasaurApp
 */
angular.module('bulbasaurApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
